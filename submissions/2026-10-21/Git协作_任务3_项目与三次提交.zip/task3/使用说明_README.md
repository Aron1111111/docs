# 任务 3 使用说明 / Задание 3

本包在 course-project 中保存项目源文件，并用 course-project.bundle 保存真实的三次本地提交。
Папка course-project содержит исходники, а course-project.bundle — три фактических локальных коммита.

## 查看已经完成的三次提交 / Просмотр готовой истории

在解压后同时包含 course-project 文件夹和 course-project.bundle 的目录打开 PowerShell 或 PyCharm Terminal：
Откройте PowerShell или Terminal PyCharm в каталоге с папкой course-project и файлом course-project.bundle:

```text
git --version
git clone ./course-project.bundle course-project-restored
cd course-project-restored
git log --oneline --reverse
git rev-list --count HEAD
git status
python tools/check_docs.py
```

正确结果：三条提交，计数 3，工作区干净，检查脚本输出 PASS。course-project-restored 必须是尚不存在的目标目录。
Ожидаются три коммита, число 3, чистое рабочее дерево и PASS. Целевой каталог course-project-restored ещё не должен существовать.

这是本项目新创建的历史，没有复制其他项目的 .git。源文件目录本身不含 .git，因此直接打开源文件后运行 log 看不到历史；需要先 clone bundle。
История создана заново для этого проекта, чужая .git не копировалась. В папке исходников .git отсутствует: для просмотра истории сначала клонируйте bundle.

提交作者 Student A 与 student-a@example.invalid 是教学示例，不是本人账号。以后提交前请在恢复的仓库中用 git config --local 设置自己的身份，不修改既有提交来伪装作者。
Автор Student A и student-a@example.invalid — учебный пример. Перед своими коммитами задайте собственное имя через git config --local; не подменяйте автора существующих коммитов.

## 从零练习 / Самостоятельное выполнение

若要亲自完成三次提交，请使用不含 .git 的 course-project 源目录，按 Word 步骤操作。最终文件已包含第三次说明；第二次提交前先去掉登记表末尾的两句说明，再于第三次提交时加入。
Для собственной работы используйте исходники course-project без .git и шаги из Word. Итоговый реестр уже содержит уточнение: перед вторым коммитом уберите две последние фразы, затем верните их в третьем.

本包不需要业务应用启动或 Python 运行按钮。只有文档检查脚本用 Python 执行；Git 命令在终端逐条运行。
Бизнес-приложение и кнопка запуска Python не нужны. Python используется только для проверки документов; команды Git выполняются в терминале.
